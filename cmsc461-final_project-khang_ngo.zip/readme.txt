jupiter database access program
khang ngo
khang4@umbc.edu
cmsc 461 databases term project

-main program is "j5main.py"
    "python j5main.py"
-connection details must be entered directly in the j5main.py file.
 at the beginning of the file
-program requires mysql.connector module, I assume this is the one
 from the mysql website given to us
-program uses the latest python, or at least the one on my computer,
 3.6.3.  i can't guarantee it'll work correctly for other versions
-the mysql server must already be running, and a database must be
 already be made, the program does not make a database, and the
 createAll.sql DOES NOT MAKE THE DATABASE
-there has to be a database called jupiter for createAll.sql to
 work. if something goes wrong, please take a look at the createAll
 file to see how it works
-all the above is explained more indepth in the report, but i also put
 it here for quick setup of the program

-its called j5 for jupiter5, because i went through five different
 versions before it started working and i needed a name to distinguish
 the folders from each other.

github: https://github.com/khang4/jupiterdb

have a good winter!